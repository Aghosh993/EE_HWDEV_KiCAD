#!/bin/bash
mv Simple5VSupply-F.Cu.gbr Simple5VSupply.GTL
mv Simple5VSupply-B.Cu.gbr Simple5VSupply.GBL
mv Simple5VSupply-F.Mask.gbr Simple5VSupply.GTS
mv Simple5VSupply-B.Mask.gbr Simple5VSupply.GBS
mv Simple5VSupply-F.SilkS.gbr Simple5VSupply.GTO
mv Simple5VSupply-B.SilkS.gbr Simple5VSupply.GBO
mv Simple5VSupply-Edge.Cuts.gbr Simple5VSupply.GKO
mv Simple5VSupply.drl Simple5VSupply.XLN
